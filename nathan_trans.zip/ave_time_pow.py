
# from multiply import *

# from each_layer_time_ import *
# from main import *
import csv
import numpy as py
from numpy.lib.shape_base import split
'''  these are the csv files name  
if we run 1000 times first data is total data we get in the csv  file.
the fisrt bracket is encoder data. the second bracket is decoder data. 

data_encoder   1000 data
data_decoder   1000 data 
data_feed_forward 2000 dada. encoder(1000).  decoder(1000) 
data_layer_norm   7000 data  encoder(3000),  decoder(4000) 
data_multi_pc     3000 data  encoder(1000) , decoder(2000)

data_matmul 
data_softmax
''' 
time = 0.0
power = 0.0
count = 0

# you can open the different csv file with above mactched file names. 
with open('data_softmax.csv', encoding= "utf-8") as csv_file:
    reader = csv.reader(csv_file)
    column = [row[-1] for row in reader]
    # for i in range(1000):
    #     birth_reader = next(reader)
    #     columns = birth_reader[-1]
    #     r= columns.split(';')
    #     count += 1 
    #     time  += float(r[-2])
    #     power += float(r[-1])

for rows in column[:10000]:        # you can modify the section of the csv file. 
    count += 1 
    r = rows.split(';')
    time  += float(r[-2])
    power += float(r[-1])


print(time, power)
print(count)
time_ave = time /(count)
power_ave = power /(count)
print("the average time %s and average power %s uJ " % (time_ave,power_ave))