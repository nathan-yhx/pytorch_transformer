

from multiply import *

from each_layer_time_ import *
# import pyJoules
# import energyusage

# from pyJoules.energy_meter import measure_energy
# from pyJoules.device.rapl_device import RaplPackageDomain
# from pyJoules.device.nvidia_device import NvidiaGPUDomain

size = 512
head = 8
d_model = 512
vocab = 1000

#x = Variable(torch.LongTensor([[100,2,421,508]]))
x = Variable(torch.LongTensor([[100,2,421,508],[491,998,1,221]])).cuda(0)

emb = Embeddings(d_model, vocab).cuda(0)

embr = emb(x)

x = embr

dropout = 0.1
max_len = 60

pe = PositionalEncoding(d_model, dropout, max_len).cuda(0)
pe_result = pe(x)

d_ff = 64
c = copy.deepcopy
dropout = 0.2
attn = MultiHeadeAttention( head ,d_model)

ff = PositionwiseFeedForward(d_model, d_ff, dropout)
x=pe_result
layer = EncoderLayer(size, c(attn), c(ff), dropout)

##################### this part is encoder
N = 1
mask = Variable(torch.zeros(8, 4, 4)).cuda(0)
en = Encoder(layer, N).cuda(0)

def eloop(x,mask):    # we can set the encoder layer running time. 
    for i in range(1000):
        en_result = en(x,mask)      

eloop(x,mask)
en_result = en(x, mask)
decoder_input = en_result
print(decoder_input)
###############    this part is for decoder 
''' the en_result is from the encoder output'''
memory = en_result
source_mask = target_mask = mask
layer = DecoderLayer(d_model, c(attn), c(attn), c(ff), dropout).cuda(0)
de = Decoder(layer, N).cuda(0)
# de_result = de(x, memory, source_mask, target_mask)

def dloop(x, memory, source_mask, target_mask):
    for i in range(1000):
        de_result = de(x, memory, source_mask, target_mask)   
dloop(x, memory, source_mask, target_mask)

###############################################################
# in the file the last colunm is power consumption. the second last is computing time. 

csv_handler_encoder.save_data()
csv_handler_ffn.save_data()
csv_handler_norm.save_data()
csv_handler_multi.save_data()
csv_handler_decoder.save_data()

print("finished !!!!!!!!!!!!!!!!!!!")


'''                    1000 times running of average time and pc data          The actual running times. 
encoder:              the average time (s)          the average power (uJ)          
feed forward            0.38752132177352905            39849.692 uJ                 (1000 times)
layer norm              0.26057388083140054            26713.725 uJ                 (3000 times) 
multi_attantion         1.7744997050762177            184663.611 uJ                 (1000 times)
one encoder-Layer       2.953773657083511             305233.091 uJ                 (1000 times)

enocder-layer = feedword + 3*layernorm + multi_attention  

decoder:
feed forward            0.3426905493736267             34837.237 uJ                  (1000 times)
layer norm              0.2366040191054344             24269.436 uJ                  (4000 times)
multi_attantion         1.5656055116653442            162697.759 uJ                  (2000 times)
one decoder-Layer       4.433566575288773             458245.328 uJ                  (1000 times)

decoder-layer = feedword + 4*layernorm + 2*multi_attention


softmax                 0.0015160369396209716             8.4756 uJ           (10000 times)
matmul                  0.2820212996006012            29159.855  uJ           (5000 times)
softmax total = softmax * 10000
matmul total = matmul * 5000 
'''