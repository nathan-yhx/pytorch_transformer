import torch 
from multiply import * 
from torch.autograd import Variable
from pyJoules.energy_meter import measure_energy
# from pyJoules.device.rapl_device import RaplPackageDomain
from pyJoules.device.nvidia_device import NvidiaGPUDomain
from pyJoules.handler.csv_handler import CSVHandler 

csv_handler_soft = CSVHandler('data_softmax.csv')


@measure_energy(handler=csv_handler_soft ,domains=[NvidiaGPUDomain(0)])
def softmax(x):
  #print("the x shape !!!!! ????",x.shape)
  a = x.shape[:-1]
  res = torch.max(x,-1)[0].view(*a,1)
   # print("res softmax ", res.shape )
  exp = torch.exp(x-res)
  
  return  exp / torch.sum(exp,axis=-1,keepdims=True)


x = torch.rand(2,8,4,4).cuda(0) # here we keep the same shape of the transformer input of softmax.
print(x.shape)
for i in range(10000): # you can change the looping times. 
  ressoft = softmax(x).cuda(0) 
 
csv_handler_soft.save_data()

# print(ressoft)
# a = Variable(torch.LongTensor([[[100.32,999.431,421.374,512],[491.432,998.31,431,221]]])).cuda(0)
# b = Variable(torch.LongTensor([[[100.32,999]
#                                ,[491,998]
#                                ,[100.31,999]
#                                ,[491,998.31]]])).cuda(0)
a = torch.rand(2,4,512).cuda(0)
b = torch.rand(512,512).cuda(0)
print(a, b)
for i in range(5000): # this is testing the  matmul_for_loop functions
                      #you can change the looping times in this for loop.
  resmat= matmul_for_loop(a,b).cuda(0)


csv_handler_matmul.save_data()