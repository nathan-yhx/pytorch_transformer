
import torch 
from pyJoules.energy_meter import measure_energy
# from pyJoules.device.rapl_device import RaplPackageDomain
from pyJoules.device.nvidia_device import NvidiaGPUDomain
from pyJoules.handler.csv_handler import CSVHandler 

csv_handler_matmul = CSVHandler('data_matmul.csv')

def cal (x,y):
  return x*y
count_multiply = 0
count_matmul = 0

#   @measure_energy(handler=csv_handler_matmul ,domains=[NvidiaGPUDomain(0)])
def the_multiply_for(a,b):
  # print("multiply")

  global count_multiply
  count_multiply += 1
  # print(" i am here in the_multiply_for !")

  if type(a) == float:
     if len(list(b.size()))== 3:

       b1,b2,b3 = b.shape
       c = torch.zeros(b1, b2, b3).cuda(a.device)
       times = torch.zeros(b1,b2,b3)
       for k in range(b1):
         for i in range(b2):
           for j in range(b3):  
            c[k,i,j]= cal(a,b[k,i,j])
     else:
        ValueError("wrong !!!")   

  elif type(b) == float:
    if len(list(a.size()))== 3:
      a1,a2,a3 = a.shape
      c = torch.zeros(a1, a2, a3).cuda(a.device)
      times = torch.zeros(a1, a2, a3)
      for k in range(a1):
        for i in range(a2):
          for j in range(a3):
            c[k,i,j] = cal(a[k,i,j] , b)
  else:

    if len(list(a.size()))== 1 and len(list(b.size()))== 3:
     a1 = len(a)
     b1,b2,b3 = b.shape
     assert a1==b3

     c = torch.zeros(b1, b2, b3).cuda(a.device)
     times = torch.zeros(b1,b2,b3)
     for k in range(b1):
       for i in range(b2):
         for j in range(b3):  
          c[k,i,j] = cal(a[j],b[k,i,j])

    elif len(list(a.size()))== 3 and len(list(b.size()))== 1:
    
     a1,a2,a3 = a.shape
     b1 = len(b)
     assert a3==b1

     c = torch.zeros(a1, a2, a3).cuda(a.device)
     times = torch.zeros(a1, a2, a3)
     for k in range(a1):
       for i in range(a2):
         for j in range(a3):
           c[k,i,j] = cal(a[k,i,j] , b[j])


    elif len(list(a.size()))== 2 and len(list(b.size()))== 3:   
     a2,a3 = a.shape
     b1,b2,b3 = b.shape
     assert a2==b2
     assert a3==b3
     c = torch.zeros(b1, b2, b3).cuda(a.device)
     times = torch.zeros(b1, b2, b3)
     for k in range(b1):
       for i in range(b2):
         for j in range(b3):
           c[k,i,j] = cal(a[i,j] , b[k,i,j])




    elif len(list(a.size()))== 3 and len(list(b.size()))== 3:
     a1,a2,a3 = a.shape
     b1,b2,b3 = b.shape
     assert a3==b3
     assert a2==b2
    
     c = torch.zeros(a1, a2, b3).cuda(a.device)
     times = torch.zeros(a1, a2, b3)
     for k in range(a1):
       for i in range(a2):
         for j in range(b3):
           c[k,i,j] =  cal(a[k,i,j] , b[k,i,j])


    elif len(list(a.size()))== 4 and len(list(b.size()))== 4:
      a1,a2,a3,a4 = a.shape
      b1,b2,b3,b4 = b.shape

      assert a1==b1
      assert a2==b2
      assert a4==b4

      c = torch.zeros(a1, a2, a3, b4).cuda(a.device)
      times = torch.zeros(a1, a2, a3, b4)
      for d in range(a1):
        for k in range(a2):
          for i in range(a3):
            for j in range(b4):
              c[d,k,i,j] =  cal(a[d,k,i,j] , b[d,k,i,j])
    
    else: 
         ValueError("wrong input ")        

  return c


@measure_energy(handler=csv_handler_matmul ,domains=[NvidiaGPUDomain(0)])
def matmul_for_loop(a,b):
  global count_matmul
  count_matmul += 1
  # print(" i am here in MATMUL_for_loop ! \n")
  # print("A and B",a.shape,b.shape)

  #count the number of multiplication
  # Filter out the set-up cost 
  # Run multiplication 1000, 2000, 3000 etc. and then create a linear model to filter out the set-up cost for multiplication



  if len(list(a.size()))== 2 and len(list(b.size())) == 3:

    a2,a3 = a.shape
    b1,b2,b3 = b.shape
    assert a3==b2
    
    c = torch.zeros(b1, a2, b3).cuda(a.device)
    for k in range(b1):
      for i in range(a2):
        for j in range(b3):
          c[k,i,j] = (a[i,:] * b[k,:,j]).sum()
   
  elif len(list(a.size()))== 2 and len(list(b.size())) == 2:
  
    a1,a2 = a.shape
    b1,b2 = b.shape
    assert a2==b1

    c = torch.zeros(a1, b2).cuda(a.device)
    for i in range(a1):
      for j in range(b2):
        c[i,j] = (a[i,:] * b[:,j]).sum()
   

  elif len(list(a.size()))== 3 and len(list(b.size())) == 2:
  
    a1,a2,a3 = a.shape
    b2,b3 = b.shape
    assert a3==b2

    c = torch.zeros(a1, a2, b3).cuda(a.device)
    for k in range(a1):
      for i in range(a2):
        for j in range(b3):
          c[k,i,j] = (a[k,i,:] * b[:,j]).sum()
         

  elif len(list(a.size()))== 3 and len(list(b.size())) == 3:
    a1,a2,a3 = a.shape
    b1,b2,b3 = b.shape
    assert a3==b2
    assert a1==b1
    
    c = torch.zeros(a1, a2, b3).cuda(a.device)
    for k in range(a1):
      for i in range(a2):
        for j in range(b3):
          c[k,i,j] = (a[k,i,:] * b[k,:,j]).sum()


  elif len(list(a.size()))== 3 and len(list(b.size())) == 4:
     a2,a3,a4 = a.shape
     b1,b2,b3,b4 = b.shape
     assert a4==b3
     assert a2==b2
     c = torch.zeros(b1, b2, a3, b4).cuda(a.device)
     for d in range(b1):
       for k in range(b2):
         for i in range(a3):
           for j in range(b4):
             c[d,k,i,j] = (a[k,i,:] * b[d,k,:,j]).sum()



  elif len(list(a.size()))== 4 and len(list(b.size())) == 3:
     a1,a2,a3,a4 = a.shape
     b2,b3,b4 = b.shape
     assert a4==b3
     assert a2==b2
     c = torch.zeros(a1, a2, a3, b4).cuda(a.device)
     for d in range(a1):
       for k in range(a2):
         for i in range(a3):
           for j in range(b4):
             c[d,k,i,j] = (a[d,k,i,:] * b[k,:,j]).sum()

  

  else: # len(list(a.size()))== 4 and len(list(b.size())) == 4:
     a1,a2,a3,a4 = a.shape
     b1,b2,b3,b4 = b.shape
     assert a4==b3
     assert a1==b1
     assert a2==b2
     c = torch.zeros(a1, a2, a3, b4).cuda(a.device)
     for d in range(a1):
       for k in range(a2):
         for i in range(a3):
           for j in range(b4):
             c[d,k,i,j] = (a[d,k,i,:] * b[d,k,:,j]).sum()


  return c

def matmul_aite(a,b):
  return a @ b
